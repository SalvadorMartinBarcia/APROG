module Main where

import ApartadoA.ApartadoA
import ApartadoB.ApartadoB
import ApartadoC.ApartadoC
import ApartadoD.ApartadoD
import ApartadoE.ApartadoE
import ApartadoF.ApartadoF
import ApartadoG.ApartadoG
import ApartadoH.ApartadoH

main :: IO ()
main = do
        mainA
        mainB
        mainC
        mainD
        mainE
        mainF
        mainG
        mainH