
module ApartadoK.Func.Factoriales where

    -- composición de funciones
    fact8 :: Integer -> Integer
    fact8 n = product (enumFromTo 1 n)

